#!/usr/bin/env python3
"""
Cubelight - an offline Minecraft launcher for Linux.

Features
  * Profiles (instances): own version, loader, memory, JVM flags, resolution, game folder
  * Vanilla, Fabric, Quilt and Forge installs, with real download progress
  * Stable offline UUIDs (same name -> same UUID, so your worlds and inventories persist)
  * Mojang's bundled Java runtime by default, or any Java you pick
  * Mod manager: enable/disable/delete installed mods, search and install from Modrinth
  * World manager: list, back up (zip), open, delete
  * Live game console with colour-coded log levels, kill button, log export
  * Playtime tracking, auto-join server, launcher behaviour after start
"""
from __future__ import annotations

import base64
import glob
import hashlib
import io
import json
import os
import queue
import random
import shlex
import shutil
import subprocess
import threading
import time
import tkinter as tk
import urllib.parse
import urllib.request
import uuid
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk
import minecraft_launcher_lib as mll

try:
    from PIL import Image, ImageOps
except ImportError:  # CustomTkinter depends on Pillow, so this is just a safety net
    Image = None

APP = "Cubelight"
APP_VERSION = "v0.0.0a"

XDG_CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
XDG_DATA = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
CONFIG_DIR = XDG_CONFIG / "cubelight"
CONFIG_FILE = CONFIG_DIR / "config.json"
DATA_DIR = XDG_DATA / "cubelight"
INSTANCES_DIR = DATA_DIR / "instances"
BACKUPS_DIR = DATA_DIR / "backups"
LEGACY_MC_DIR = XDG_DATA / "minecraft_offline"  # location used by the original script

LOADERS = ["Vanilla", "Fabric", "Quilt", "Forge"]
AFTER_LAUNCH = ["Keep open", "Hide while playing", "Close launcher"]
PERF_FLAGS = [
    "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200",
    "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC",
    "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40",
    "-XX:G1HeapRegionSize=8M", "-XX:G1ReservePercent=20",
]
MODRINTH = "https://api.modrinth.com/v2"
USER_AGENT = f"{APP}/{APP_VERSION} (offline-launcher)"

# --- Palette: deepslate + lantern amber (light/dark pairs) ---------------------------
BG = ("#e9edf2", "#15181e")
SIDE = ("#dde3ea", "#0f1217")
CARD = ("#f7f9fb", "#1e232b")
CARD_HI = ("#e3e8ee", "#2a303a")
INK = ("#1d2128", "#ece8e0")
MUTED = ("#5d6673", "#8f98a6")
AMBER = ("#d98a1f", "#f0a63a")
AMBER_HOVER = ("#c47a15", "#ffbb55")
ON_AMBER = "#1b1305"
DANGER = ("#c2412d", "#e5604d")
DANGER_HOVER = ("#a9351f", "#f27561")

FAMILY = "TkDefaultFont"


def font(size=13, weight="normal"):
    return ctk.CTkFont(family=FAMILY, size=size, weight=weight)


# ======================================================================================
# Persistence
# ======================================================================================
DEFAULT_SETTINGS = {
    "appearance": "Dark",
    "after_launch": "Keep open",
    "default_ram": 2048,
    "java_path": "",
    "mc_dir": str(LEGACY_MC_DIR),
    "show_snapshots": False,
    "app_name": "Cubelight",
    "tagline": "Offline launcher",
    "banner": "",
}


def system_ram_mb() -> int:
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal"):
                    return int(line.split()[1]) // 1024
    except OSError:
        pass
    return 8192


def max_ram_mb() -> int:
    """Total RAM of this PC, rounded down to a 256 MB step."""
    return max(2048, (system_ram_mb() // 256) * 256)


def new_profile(name="New profile", version="1.20.4", loader="Vanilla", ram=2048) -> dict:
    return {
        "id": uuid.uuid4().hex[:8],
        "name": name,
        "version": version,
        "loader": loader,
        "ram_mb": ram,
        "perf_flags": False,
        "jvm_args": "",
        "game_dir": "",
        "java_path": "",
        "width": 854,
        "height": 480,
        "fullscreen": False,
        "server": "",
        "last_played": 0,
        "playtime": 0,
    }


class Store:
    def __init__(self):
        self.data = {}
        self.load()

    @property
    def settings(self) -> dict:
        return self.data["settings"]

    @property
    def profiles(self) -> list:
        return self.data["profiles"]

    def load(self):
        try:
            self.data = json.loads(CONFIG_FILE.read_text())
        except (OSError, ValueError):
            self.data = {}
        d = self.data
        d.setdefault("settings", {})
        for k, v in DEFAULT_SETTINGS.items():
            d["settings"].setdefault(k, v)
        d.setdefault("accounts", ["OfflinePlayer"])
        d.setdefault("active_account", d["accounts"][0])
        if not d.get("profiles"):
            p = new_profile("Default", "1.20.4", "Vanilla", d["settings"]["default_ram"])
            # Keep existing worlds from the original launcher if they are there.
            if (Path(d["settings"]["mc_dir"]) / "saves").exists():
                p["game_dir"] = d["settings"]["mc_dir"]
            d["profiles"] = [p]
            d["selected_profile"] = p["id"]
        d.setdefault("selected_profile", d["profiles"][0]["id"])
        self.save()

    def save(self):
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            tmp = CONFIG_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, indent=2))
            tmp.replace(CONFIG_FILE)
        except OSError as e:
            print("Could not save config:", e)

    def profile(self, pid=None) -> dict:
        pid = pid or self.data["selected_profile"]
        for p in self.profiles:
            if p["id"] == pid:
                return p
        return self.profiles[0]

    def unique_name(self, name, ignore_id=None) -> str:
        names = {p["name"] for p in self.profiles if p["id"] != ignore_id}
        if name not in names:
            return name
        i = 2
        while f"{name} ({i})" in names:
            i += 1
        return f"{name} ({i})"


# ======================================================================================
# Minecraft helpers (no UI in here)
# ======================================================================================
def offline_uuid(name: str) -> str:
    """Same algorithm as Java's UUID.nameUUIDFromBytes('OfflinePlayer:<name>')."""
    h = bytearray(hashlib.md5(f"OfflinePlayer:{name}".encode()).digest())
    h[6] = (h[6] & 0x0F) | 0x30
    h[8] = (h[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(h)))


def valid_username(name: str) -> bool:
    return 3 <= len(name) <= 16 and all(c.isalnum() or c == "_" for c in name) and name.isascii()


def find_javas() -> list[tuple[str, str]]:
    cands = glob.glob("/usr/lib/jvm/*/bin/java") + glob.glob("/usr/lib64/jvm/*/bin/java")
    cands += glob.glob(os.path.expanduser("~/.sdkman/candidates/java/*/bin/java"))
    cands += glob.glob(os.path.expanduser("~/.jdks/*/bin/java"))
    w = shutil.which("java")
    if w:
        cands.append(w)
    seen, out = set(), []
    for c in cands:
        if not os.path.isfile(c):
            continue
        real = os.path.realpath(c)
        if real in seen:
            continue
        seen.add(real)
        label = Path(c).parent.parent.name if "/bin/java" in c else c
        out.append((label, c))
    return out


def game_dir_for(p: dict) -> Path:
    return Path(p["game_dir"]) if p.get("game_dir") else INSTANCES_DIR / p["id"]


def installed_ids(mc_dir) -> list[str]:
    try:
        return [v["id"] for v in mll.utils.get_installed_versions(str(mc_dir))]
    except Exception:
        return []


def resolve_version(mc_dir, p: dict):
    """Return the installed version id that launches this profile, or None."""
    ids = installed_ids(mc_dir)
    mc, loader = p["version"], p["loader"]
    if loader == "Vanilla":
        return mc if mc in ids else None
    if loader in ("Fabric", "Quilt"):
        pre = f"{loader.lower()}-loader-"
        c = [i for i in ids if i.startswith(pre) and i.endswith("-" + mc)]
    else:
        c = [i for i in ids if "forge" in i.lower() and i.startswith(mc + "-")]
    return sorted(c)[-1] if c else None


def install_profile(mc_dir, p: dict, cb: dict):
    mc, loader = p["version"], p["loader"]
    java = shutil.which("java")
    os.makedirs(mc_dir, exist_ok=True)
    if loader == "Vanilla":
        mll.install.install_minecraft_version(mc, str(mc_dir), callback=cb)
    elif loader == "Fabric":
        if not mll.fabric.is_minecraft_version_supported(mc):
            raise RuntimeError(f"Fabric does not support Minecraft {mc}.")
        mll.fabric.install_fabric(mc, str(mc_dir), callback=cb, java=java)
    elif loader == "Quilt":
        if not mll.quilt.is_minecraft_version_supported(mc):
            raise RuntimeError(f"Quilt does not support Minecraft {mc}.")
        mll.quilt.install_quilt(mc, str(mc_dir), callback=cb, java=java)
    else:
        fv = mll.forge.find_forge_version(mc)
        if not fv:
            raise RuntimeError(f"No Forge build found for Minecraft {mc}.")
        if not java:
            raise RuntimeError("Installing Forge needs Java on your PATH (e.g. openjdk-17).")
        mll.forge.install_forge_version(fv, str(mc_dir), callback=cb, java=java)


def build_command(mc_dir, p: dict, settings: dict, username: str, version_id: str) -> list[str]:
    ram = int(p.get("ram_mb") or settings["default_ram"])
    jvm = [f"-Xms{min(ram, 1024)}M", f"-Xmx{ram}M"]
    if p.get("perf_flags"):
        jvm += PERF_FLAGS
    if p.get("jvm_args", "").strip():
        jvm += shlex.split(p["jvm_args"])
    opts = {
        "username": username,
        "uuid": offline_uuid(username),
        "token": "0",
        "launcherName": APP,
        "launcherVersion": APP_VERSION,
        "gameDirectory": str(game_dir_for(p)),
        "jvmArguments": jvm,
    }
    java = p.get("java_path") or settings.get("java_path")
    if java:
        opts["executablePath"] = java
    if p.get("width") and p.get("height") and not p.get("fullscreen"):
        opts["customResolution"] = True
        opts["resolutionWidth"] = str(p["width"])
        opts["resolutionHeight"] = str(p["height"])
    if p.get("server"):
        host, _, port = p["server"].partition(":")
        opts["server"] = host
        if port.isdigit():
            opts["port"] = port
    cmd = mll.command.get_minecraft_command(version_id, str(mc_dir), opts)
    if p.get("fullscreen"):
        cmd.append("--fullscreen")
    return cmd


# --- Modrinth --------------------------------------------------------------------------
def http_json(url, params=None):
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)


def modrinth_search(query, mc, loader, offset=0):
    facets = [["project_type:mod"]]
    if mc:
        facets.append([f"versions:{mc}"])
    if loader and loader != "Vanilla":
        cats = [f"categories:{loader.lower()}"]
        if loader == "Quilt":
            cats.append("categories:fabric")
        facets.append(cats)
    return http_json(f"{MODRINTH}/search", {
        "query": query, "facets": json.dumps(facets), "limit": 20, "offset": offset,
    })["hits"]


def modrinth_version(project_id, mc, loader):
    loaders = [loader.lower()] + (["fabric"] if loader == "Quilt" else [])
    vs = http_json(f"{MODRINTH}/project/{project_id}/version", {
        "game_versions": json.dumps([mc]), "loaders": json.dumps(loaders),
    })
    return vs[0] if vs else None


def download_file(url, dest: Path, progress=None):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    tmp = dest.with_suffix(dest.suffix + ".part")
    with urllib.request.urlopen(req, timeout=30) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while chunk := r.read(65536):
            f.write(chunk)
            done += len(chunk)
            if progress and total:
                progress(done / total)
    tmp.replace(dest)


def install_mod(project_id, mc, loader, mods_dir: Path, depth=0, seen=None) -> list[str]:
    """Install a mod and its required dependencies. Returns installed filenames."""
    seen = seen if seen is not None else set()
    if project_id in seen or depth > 2:
        return []
    seen.add(project_id)
    v = modrinth_version(project_id, mc, loader)
    if not v:
        if depth == 0:
            raise RuntimeError(f"No {loader} build of this mod for Minecraft {mc}.")
        return []
    files = v["files"]
    f = next((x for x in files if x.get("primary")), files[0])
    mods_dir.mkdir(parents=True, exist_ok=True)
    download_file(f["url"], mods_dir / f["filename"])
    done = [f["filename"]]
    for dep in v.get("dependencies", []):
        if dep.get("dependency_type") == "required" and dep.get("project_id"):
            try:
                done += install_mod(dep["project_id"], mc, loader, mods_dir, depth + 1, seen)
            except Exception:
                pass
    return done


# --- misc ------------------------------------------------------------------------------
def human_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def dir_size(path: Path) -> int:
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def fmt_playtime(sec: int) -> str:
    if sec < 60:
        return "none yet" if sec == 0 else "under a minute"
    h, m = divmod(sec // 60, 60)
    return f"{h} h {m} min" if h else f"{m} min"


def fmt_date(ts: float) -> str:
    return time.strftime("%b %d, %H:%M", time.localtime(ts)) if ts else "never"


def open_path(path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        webbrowser.open(path.as_uri())


# ======================================================================================
# Small UI helpers
# ======================================================================================
def button(master, text, command, kind="ghost", **kw):
    styles = {
        "primary": dict(fg_color=AMBER, hover_color=AMBER_HOVER, text_color=ON_AMBER),
        "ghost": dict(fg_color=CARD_HI, hover_color=("#d3dae3", "#363d49"), text_color=INK),
        "danger": dict(fg_color=CARD_HI, hover_color=DANGER, text_color=DANGER),
    }
    kw = {**dict(corner_radius=8, font=font(13), height=34), **styles[kind], **kw}
    b = ctk.CTkButton(master, text=text, command=command, **kw)
    if kind == "danger":
        b.bind("<Enter>", lambda e: b.configure(text_color="#ffffff"), add="+")
        b.bind("<Leave>", lambda e: b.configure(text_color=DANGER), add="+")
    return b


def label(master, text, size=13, weight="normal", muted=False, **kw):
    return ctk.CTkLabel(master, text=text, font=font(size, weight),
                        text_color=MUTED if muted else INK, **kw)


def card(master, **kw):
    return ctk.CTkFrame(master, fg_color=CARD, corner_radius=12, **kw)


def option_menu(master, values, command=None, **kw):
    opts = dict(
        font=font(13), dropdown_font=font(13), fg_color=CARD_HI, button_color=CARD_HI,
        button_hover_color=("#d3dae3", "#363d49"), text_color=INK, dropdown_fg_color=CARD,
        dropdown_text_color=INK, dropdown_hover_color=CARD_HI, corner_radius=8, height=34)
    opts.update(kw)
    return ctk.CTkOptionMenu(master, values=values or [""], command=command, **opts)


def entry(master, **kw):
    return ctk.CTkEntry(master, font=font(13), fg_color=CARD_HI, border_width=0,
                        text_color=INK, corner_radius=8, height=34, **kw)


class Page(ctk.CTkFrame):
    title = ""

    def __init__(self, parent, app):
        super().__init__(parent, fg_color="transparent")
        self.app = app

    def on_show(self):
        pass

    def header(self, title, subtitle=None):
        box = ctk.CTkFrame(self, fg_color="transparent")
        box.pack(fill="x", padx=28, pady=(24, 12))
        label(box, title, 24, "bold").pack(anchor="w")
        if subtitle:
            label(box, subtitle, 13, muted=True).pack(anchor="w", pady=(2, 0))
        return box


# ======================================================================================
# Play page
# ======================================================================================
def _hex(c):
    return tuple(int(c[i:i + 2], 16) for i in (1, 3, 5))


def _rgb(t):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in t)


def _mix(a, b, t):
    return _rgb(tuple(x + (y - x) * t for x, y in zip(_hex(a), _hex(b))))


def draw_cube(cv, cx, cy, u, seed=11):
    """Isometric grass block, drawn procedurally so no image assets are needed."""
    rnd = random.Random(seed)
    n, k, s = 8, u * 0.866, u * 0.5

    def P(a, b, c):
        return (cx + (a - b) * k, cy + (a + b) * s - c * u)

    def jit(hexc, f=1.0, amt=14):
        d = rnd.randint(-amt, amt)
        return _rgb(tuple((v + d) * f for v in _hex(hexc)))

    grass, grass2, dirt, stone = "#6f9b43", "#5d8a37", "#8b5d3c", "#7a7d82"
    for a in range(n):
        for b in range(n):
            col = jit(grass)
            cv.create_polygon([P(a, b, n), P(a + 1, b, n), P(a + 1, b + 1, n), P(a, b + 1, n)],
                              fill=col, outline=col)
    for face, factor in (("left", 0.82), ("right", 0.62)):
        drip = [rnd.choice([1, 1, 2, 2, 3]) for _ in range(n)]
        for i in range(n):
            for c in range(n):
                depth = n - 1 - c
                if depth < drip[i]:
                    base = grass2
                elif rnd.random() < 0.07:
                    base = stone
                else:
                    base = dirt
                col = jit(base, factor, 10)
                if face == "left":
                    pts = [P(i, n, c), P(i + 1, n, c), P(i + 1, n, c + 1), P(i, n, c + 1)]
                else:
                    pts = [P(n, i, c), P(n, i + 1, c), P(n, i + 1, c + 1), P(n, i, c + 1)]
                cv.create_polygon(pts, fill=col, outline=col)


class PlayPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.hero = tk.Canvas(self, height=280, highlightthickness=0, bd=0, bg="#0f1218")
        self.hero.pack(fill="x")
        self.hero.bind("<Configure>", lambda e: self.draw_hero())
        self.banner_native, self.banner_error = False, ""

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=28, pady=22)
        body.grid_columnconfigure(2, weight=1)

        label(body, "Player", 12, muted=True).grid(row=0, column=0, sticky="w")
        label(body, "Profile", 12, muted=True).grid(row=0, column=1, sticky="w", padx=(14, 0))

        self.account = ctk.CTkComboBox(
            body, values=app.store.data["accounts"], width=210, height=40, font=font(14),
            fg_color=CARD_HI, border_width=0, button_color=CARD_HI, text_color=INK,
            dropdown_fg_color=CARD, dropdown_text_color=INK, dropdown_font=font(13),
            corner_radius=8, command=lambda v: self.update_uuid())
        self.account.grid(row=1, column=0, sticky="w", pady=(4, 0))
        self.account.bind("<KeyRelease>", lambda e: self.update_uuid())

        self.profile_menu = option_menu(body, [], command=self.on_profile, width=250, height=40)
        self.profile_menu.grid(row=1, column=1, sticky="w", padx=(14, 0), pady=(4, 0))

        self.play_btn = button(body, "Play", app.on_play_button, "primary", width=190, height=56,
                               corner_radius=10, font=font(20, "bold"))
        self.play_btn.grid(row=0, column=3, rowspan=2, sticky="e")

        self.uuid_lbl = label(body, "", 11, muted=True)
        self.uuid_lbl.grid(row=2, column=0, columnspan=3, sticky="w", pady=(6, 0))

        self.bar = ctk.CTkProgressBar(body, height=8, corner_radius=4, progress_color=AMBER,
                                      fg_color=CARD_HI)
        self.bar.set(0)
        self.bar.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(26, 6))
        self.status = label(body, "Ready.", 13, muted=True)
        self.status.grid(row=4, column=0, columnspan=4, sticky="w")

        self.stats = label(body, "", 13)
        self.stats.grid(row=5, column=0, columnspan=4, sticky="w", pady=(22, 0))

    # -- hero ------------------------------------------------------------------------
    def banner_image(self, w, h):
        """Custom banner, cropped to fit and darkened on the left so the title stays readable.

        Returns a Tk image or None. The reason for a failure is kept in self.banner_error.
        """
        self.banner_error = ""
        path = self.app.store.settings.get("banner", "")
        if not path:
            return None
        if not os.path.isfile(path):
            self.banner_error = "File not found: " + path
            return None
        key = (path, os.path.getmtime(path), w, h)
        if getattr(self, "_banner_key", None) == key:
            return self._banner_img
        self.banner_native = False
        try:
            if Image is None:
                return self._native_banner(path, key)
            img = ImageOps.fit(Image.open(path).convert("RGB"), (w, h), Image.LANCZOS)
            mask = Image.new("L", (w, 1))
            for x in range(w):
                t = min(1.0, x / (w * 0.75))
                mask.putpixel((x, 0), int(190 * (1 - t) ** 1.5))
            mask = mask.resize((w, h))
            img = Image.composite(Image.new("RGB", (w, h), (8, 10, 14)), img, mask)
            # Hand Tk a PNG directly: avoids PIL.ImageTk, which some distros ship separately.
            buf = io.BytesIO()
            img.save(buf, "PNG")
            self._banner_img = tk.PhotoImage(data=base64.b64encode(buf.getvalue()))
            self._banner_key = key
            return self._banner_img
        except Exception as e:
            self.banner_error = f"{type(e).__name__}: {e}"
            print("Banner error:", self.banner_error)
            return None

    def _native_banner(self, path, key):
        """No-Pillow fallback: Tk can only read PNG/GIF and scale by whole numbers."""
        if not path.lower().endswith((".png", ".gif")):
            raise RuntimeError("Without Pillow only PNG and GIF work. For JPG/WebP run: pip install pillow")
        w, h = key[2], key[3]
        src = tk.PhotoImage(file=path)
        if src.width() < w or src.height() < h:
            z = -(-max(w, h) // min(src.width(), src.height()))  # ceil: make it cover the banner
            src = src.zoom(z, z)
        iw, ih = src.width(), src.height()
        n = max(1, min(iw // w, ih // h))
        cw, ch = w * n, h * n
        x1, y1 = max(0, (iw - cw) // 2), max(0, (ih - ch) // 2)
        out = tk.PhotoImage(width=w, height=h)
        out.tk.call(out, "copy", src, "-from", x1, y1, min(iw, x1 + cw), min(ih, y1 + ch),
                    "-subsample", n, n)
        self._banner_img, self._banner_key = out, key
        self.banner_native = True
        return out

    def draw_hero(self):
        cv = self.hero
        w, h = cv.winfo_width(), cv.winfo_height()
        if w < 50:
            return
        cv.delete("all")
        st = self.app.store.settings
        photo = self.banner_image(w, h)
        if photo:
            cv.create_image(0, 0, anchor="nw", image=photo)
        else:
            top, bottom = "#0d1016", "#3b2c2a"
            for y in range(0, h, 3):
                col = _mix(top, bottom, (y / h) ** 1.6)
                cv.create_rectangle(0, y, w, y + 3, fill=col, outline=col)
            rnd = random.Random(3)
            for _ in range(70):
                x, y = rnd.randint(0, w), rnd.randint(0, int(h * 0.65))
                c = _mix("#3a4256", "#c9c3b4", rnd.random())
                cv.create_rectangle(x, y, x + 2, y + 2, fill=c, outline=c)
            glow = h - 6
            for i in range(6):  # warm horizon glow
                c = _mix("#3b2c2a", "#f0a63a", (6 - i) / 14)
                cv.create_rectangle(0, glow - i * 3, w, glow - i * 3 + 3, fill=c, outline=c)
            draw_cube(cv, w * 0.80, h * 0.50, 14)
        p = self.app.store.profile()
        name = st["app_name"] or APP
        size = 44 if len(name) <= 12 else max(22, int(44 * 12 / len(name)))
        if self.banner_native:  # no Pillow, so no darkened gradient: use drop shadows for legibility
            for dx, dy in ((3, 3), (2, 2), (-1, 2), (2, -1)):
                cv.create_text(36 + dx, h * 0.36 + dy, anchor="w", text=name, fill="#05070a",
                               font=(FAMILY, size, "bold"))
                cv.create_text(38 + dx, h * 0.36 + 44 + dy, anchor="w", text=st["tagline"], fill="#05070a",
                               font=(FAMILY, 15))
                cv.create_text(38 + dx, h * 0.36 + 74 + dy, anchor="w", font=(FAMILY, 12), fill="#05070a",
                               text=f"{p['name']}  -  {p['loader']} {p['version']}")
        cv.create_text(36, h * 0.36, anchor="w", text=name, fill="#f4efe6", font=(FAMILY, size, "bold"))
        cv.create_text(38, h * 0.36 + 44, anchor="w", fill="#e0d3bd", font=(FAMILY, 15), text=st["tagline"])
        cv.create_text(38, h * 0.36 + 74, anchor="w", fill="#b9a98c", font=(FAMILY, 12),
                       text=f"{p['name']}  -  {p['loader']} {p['version']}")

    # -- state -----------------------------------------------------------------------
    def on_show(self):
        s = self.app.store
        names = [p["name"] for p in s.profiles]
        self.profile_menu.configure(values=names)
        self.profile_menu.set(s.profile()["name"])
        self.account.configure(values=s.data["accounts"])
        if not self.account.get():
            self.account.set(s.data["active_account"])
        self.update_uuid()
        self.update_stats()
        self.draw_hero()

    def update_uuid(self):
        name = self.account.get().strip()
        if valid_username(name):
            self.uuid_lbl.configure(text=f"Offline UUID  {offline_uuid(name)}", text_color=MUTED)
        else:
            self.uuid_lbl.configure(text="Use 3-16 letters, numbers or underscores.", text_color=DANGER)

    def update_stats(self):
        p = self.app.store.profile()
        ram = p.get("ram_mb") or self.app.store.settings["default_ram"]
        self.stats.configure(
            text=f"Last played {fmt_date(p['last_played'])}     Time played {fmt_playtime(p['playtime'])}"
                 f"     Memory {ram} MB")

    def on_profile(self, name):
        for p in self.app.store.profiles:
            if p["name"] == name:
                self.app.store.data["selected_profile"] = p["id"]
                self.app.store.save()
        self.update_stats()
        self.draw_hero()

    def set_state(self, state):
        txt = {"idle": "Play", "busy": "Preparing...", "running": "Stop"}[state]
        self.play_btn.configure(text=txt, state="disabled" if state == "busy" else "normal")
        if state == "running":
            self.play_btn.configure(fg_color=CARD_HI, hover_color=DANGER, text_color=INK)
        else:
            self.play_btn.configure(fg_color=AMBER, hover_color=AMBER_HOVER, text_color=ON_AMBER)
        self.profile_menu.configure(state="normal" if state == "idle" else "disabled")

    def set_progress(self, frac):
        self.bar.configure(mode="determinate")
        self.bar.set(max(0.0, min(1.0, frac)))

    def set_status(self, text):
        self.status.configure(text=text)


# ======================================================================================
# Profile editor + profiles page
# ======================================================================================
class ProfileDialog(ctk.CTkToplevel):
    def __init__(self, app, profile=None, on_save=None):
        super().__init__(app)
        self.app, self.on_save = app, on_save
        self.is_new = profile is None
        self.p = dict(profile) if profile else new_profile(
            ram=app.store.settings["default_ram"], version=app.default_version())
        self.title("New profile" if self.is_new else f"Edit {self.p['name']}")
        self.geometry("560x720")
        self.configure(fg_color=BG)
        self.transient(app)

        body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=12, pady=(12, 0))
        body.grid_columnconfigure(0, weight=1)

        def row(title):
            label(body, title, 12, muted=True).pack(anchor="w", padx=8, pady=(12, 3))

        row("Name")
        self.name = entry(body)
        self.name.insert(0, self.p["name"])
        self.name.pack(fill="x", padx=8)

        row("Minecraft version")
        vrow = ctk.CTkFrame(body, fg_color="transparent")
        vrow.pack(fill="x", padx=8)
        self.version = ctk.CTkComboBox(vrow, values=[self.p["version"]], font=font(13), height=34,
                                       fg_color=CARD_HI, border_width=0, button_color=CARD_HI,
                                       text_color=INK, dropdown_fg_color=CARD, dropdown_text_color=INK,
                                       corner_radius=8)
        self.version.set(self.p["version"])
        self.version.pack(side="left", fill="x", expand=True)
        self.snap = ctk.CTkSwitch(vrow, text="Snapshots", font=font(12), progress_color=AMBER,
                                  command=self.fill_versions)
        if app.store.settings["show_snapshots"]:
            self.snap.select()
        self.snap.pack(side="left", padx=(12, 0))

        row("Mod loader")
        self.loader = ctk.CTkSegmentedButton(
            body, values=LOADERS, font=font(13), selected_color=AMBER, selected_hover_color=AMBER_HOVER,
            unselected_color=CARD_HI, unselected_hover_color=("#d3dae3", "#363d49"),
            text_color=INK, fg_color=CARD_HI)
        self.loader.set(self.p["loader"])
        self.loader.pack(fill="x", padx=8)

        row(f"Memory  (this PC has {system_ram_mb() / 1024:.1f} GB)")
        mrow = ctk.CTkFrame(body, fg_color="transparent")
        mrow.pack(fill="x", padx=8)
        hi = max_ram_mb()
        self.ram = ctk.CTkSlider(mrow, from_=1024, to=hi, number_of_steps=max(1, (hi - 1024) // 256),
                                 progress_color=AMBER, button_color=AMBER, button_hover_color=AMBER_HOVER,
                                 command=self.on_ram)
        self.ram.set(min(max(self.p["ram_mb"], 1024), hi))
        self.ram.pack(side="left", fill="x", expand=True)
        self.ram_lbl = label(mrow, "", 13, width=80)
        self.ram_lbl.pack(side="left", padx=(10, 0))
        self.on_ram(self.ram.get())

        row("Window")
        wrow = ctk.CTkFrame(body, fg_color="transparent")
        wrow.pack(fill="x", padx=8)
        self.w = entry(wrow, width=80)
        self.w.insert(0, str(self.p["width"]))
        self.h = entry(wrow, width=80)
        self.h.insert(0, str(self.p["height"]))
        self.w.pack(side="left")
        label(wrow, "x", 13, muted=True).pack(side="left", padx=8)
        self.h.pack(side="left")
        self.fs = ctk.CTkSwitch(wrow, text="Fullscreen", font=font(13), progress_color=AMBER)
        if self.p["fullscreen"]:
            self.fs.select()
        self.fs.pack(side="left", padx=(18, 0))

        row("Auto-join server (host or host:port, optional)")
        self.server = entry(body)
        self.server.insert(0, self.p["server"])
        self.server.pack(fill="x", padx=8)

        row("Java")
        javas = find_javas()
        self.java_map = {"Automatic (Mojang runtime)": ""}
        for lbl, path in javas:
            self.java_map[f"{lbl}  -  {path}"] = path
        self.java = option_menu(body, list(self.java_map))
        cur = next((k for k, v in self.java_map.items() if v == self.p["java_path"]), None)
        self.java.set(cur or "Automatic (Mojang runtime)")
        self.java.pack(fill="x", padx=8)

        row("Extra JVM arguments")
        self.perf = ctk.CTkSwitch(body, text="Use performance flags (G1GC tuned)", font=font(13),
                                  progress_color=AMBER)
        if self.p["perf_flags"]:
            self.perf.select()
        self.perf.pack(anchor="w", padx=8, pady=(0, 6))
        self.jvm = entry(body, placeholder_text="-Dfoo=bar -XX:+SomeFlag")
        self.jvm.insert(0, self.p["jvm_args"])
        self.jvm.pack(fill="x", padx=8)

        row("Game folder (empty = private folder for this profile)")
        grow = ctk.CTkFrame(body, fg_color="transparent")
        grow.pack(fill="x", padx=8, pady=(0, 12))
        self.gdir = entry(grow, placeholder_text=str(INSTANCES_DIR / self.p["id"]))
        self.gdir.insert(0, self.p["game_dir"])
        self.gdir.pack(side="left", fill="x", expand=True)
        button(grow, "Browse", self.browse, width=80).pack(side="left", padx=(8, 0))

        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", padx=20, pady=14)
        button(bar, "Save profile", self.save, "primary", width=140).pack(side="right")
        button(bar, "Cancel", self.destroy, width=90).pack(side="right", padx=(0, 8))

        self.fill_versions()
        app.fetch_versions(lambda: self.winfo_exists() and self.fill_versions())
        self.after(150, self._grab)

    def _grab(self):
        try:
            self.lift()
            self.grab_set()
        except tk.TclError:
            pass

    def on_ram(self, v):
        self.ram_lbl.configure(text=f"{int(v)} MB")

    def browse(self):
        d = filedialog.askdirectory(parent=self)
        if d:
            self.gdir.delete(0, "end")
            self.gdir.insert(0, d)

    def fill_versions(self):
        vals = self.app.version_choices(bool(self.snap.get()))
        cur = self.version.get()
        if cur and cur not in vals:
            vals.insert(0, cur)
        self.version.configure(values=vals)

    def save(self):
        name = self.name.get().strip()
        ver = self.version.get().strip()
        if not name or not ver:
            messagebox.showerror("Missing info", "Give the profile a name and a version.", parent=self)
            return
        try:
            w, h = int(self.w.get()), int(self.h.get())
        except ValueError:
            messagebox.showerror("Window size", "Width and height must be numbers.", parent=self)
            return
        try:
            shlex.split(self.jvm.get())
        except ValueError as e:
            messagebox.showerror("JVM arguments", f"Could not parse arguments: {e}", parent=self)
            return
        s = self.app.store
        self.p.update(
            name=s.unique_name(name, None if self.is_new else self.p["id"]), version=ver,
            loader=self.loader.get(), ram_mb=int(self.ram.get()), width=w, height=h,
            fullscreen=bool(self.fs.get()), server=self.server.get().strip(),
            java_path=self.java_map.get(self.java.get(), ""), perf_flags=bool(self.perf.get()),
            jvm_args=self.jvm.get().strip(), game_dir=self.gdir.get().strip())
        self.grab_release()
        self.destroy()
        if self.on_save:
            self.on_save(self.p, self.is_new)


class ProfilesPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        h = self.header("Profiles", "Each profile keeps its own version, loader, memory and files.")
        button(h, "New profile", self.new, "primary", width=130).place(relx=1.0, rely=0.5, anchor="e")
        self.list = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list.pack(fill="both", expand=True, padx=16, pady=(0, 16))

    def on_show(self):
        for w in self.list.winfo_children():
            w.destroy()
        s = self.app.store
        for p in s.profiles:
            self.add_card(p, p["id"] == s.data["selected_profile"])

    def add_card(self, p, selected):
        c = card(self.list)
        c.pack(fill="x", padx=12, pady=6)
        left = ctk.CTkFrame(c, fg_color="transparent")
        left.pack(side="left", fill="x", expand=True, padx=18, pady=14)
        title = label(left, p["name"] + ("   (selected)" if selected else ""), 16, "bold")
        title.pack(anchor="w")
        ram = p.get("ram_mb") or self.app.store.settings["default_ram"]
        label(left, f"{p['loader']} {p['version']}   -   {ram} MB   -   played {fmt_playtime(p['playtime'])}",
              12, muted=True).pack(anchor="w", pady=(3, 0))
        right = ctk.CTkFrame(c, fg_color="transparent")
        right.pack(side="right", padx=14)
        if not selected:
            button(right, "Select", lambda p=p: self.select(p), width=70).pack(side="left", padx=3)
        button(right, "Edit", lambda p=p: self.edit(p), width=60).pack(side="left", padx=3)
        button(right, "Copy", lambda p=p: self.duplicate(p), width=60).pack(side="left", padx=3)
        button(right, "Folder", lambda p=p: open_path(game_dir_for(p)), width=70).pack(side="left", padx=3)
        button(right, "Delete", lambda p=p: self.delete(p), "danger", width=70).pack(side="left", padx=3)

    def select(self, p):
        self.app.store.data["selected_profile"] = p["id"]
        self.app.store.save()
        self.on_show()

    def new(self):
        ProfileDialog(self.app, None, self.saved)

    def edit(self, p):
        ProfileDialog(self.app, p, self.saved)

    def saved(self, p, is_new):
        s = self.app.store
        if is_new:
            s.profiles.append(p)
            s.data["selected_profile"] = p["id"]
        else:
            for i, q in enumerate(s.profiles):
                if q["id"] == p["id"]:
                    s.profiles[i] = p
        s.save()
        self.on_show()

    def duplicate(self, p):
        q = dict(p, id=uuid.uuid4().hex[:8], last_played=0, playtime=0, game_dir="")
        q["name"] = self.app.store.unique_name(p["name"] + " copy")
        self.app.store.profiles.append(q)
        self.app.store.save()
        self.on_show()

    def delete(self, p):
        s = self.app.store
        if len(s.profiles) == 1:
            messagebox.showinfo("Profiles", "You need at least one profile.")
            return
        if not messagebox.askyesno("Delete profile", f"Delete '{p['name']}'?\n\nIts game files stay on disk."):
            return
        s.data["profiles"] = [q for q in s.profiles if q["id"] != p["id"]]
        if s.data["selected_profile"] == p["id"]:
            s.data["selected_profile"] = s.profiles[0]["id"]
        s.save()
        self.on_show()


# ======================================================================================
# Mods page
# ======================================================================================
class ModsPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.head = self.header("Mods")
        self.info = label(self.head, "", 13, muted=True)
        self.info.pack(anchor="w", pady=(2, 0))
        tools = ctk.CTkFrame(self.head, fg_color="transparent")
        tools.place(relx=1.0, rely=0.5, anchor="e")
        button(tools, "Open folder", lambda: open_path(self.mods_dir()), width=110).pack(side="left", padx=4)
        button(tools, "Refresh", self.on_show, width=80).pack(side="left")

        self.tabs = ctk.CTkSegmentedButton(
            self, values=["Installed", "Browse Modrinth"], command=self.switch, font=font(13),
            selected_color=AMBER, selected_hover_color=AMBER_HOVER, unselected_color=CARD_HI,
            unselected_hover_color=("#d3dae3", "#363d49"), text_color=INK, fg_color=CARD_HI)
        self.tabs.pack(anchor="w", padx=28, pady=(0, 10))
        self.tabs.set("Installed")

        self.installed = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.browse = ctk.CTkFrame(self, fg_color="transparent")
        srow = ctk.CTkFrame(self.browse, fg_color="transparent")
        srow.pack(fill="x", padx=28)
        self.query = entry(srow, placeholder_text="Search mods (e.g. sodium, journeymap)")
        self.query.pack(side="left", fill="x", expand=True)
        self.query.bind("<Return>", lambda e: self.search())
        button(srow, "Search", self.search, "primary", width=90).pack(side="left", padx=(8, 0))
        self.results = ctk.CTkScrollableFrame(self.browse, fg_color="transparent")
        self.results.pack(fill="both", expand=True, padx=16, pady=(8, 16))
        self.msg = label(self.browse, "", 12, muted=True)
        self.msg.pack(anchor="w", padx=28, pady=(0, 8))
        self.switch("Installed")

    def profile(self):
        return self.app.store.profile()

    def mods_dir(self) -> Path:
        return game_dir_for(self.profile()) / "mods"

    def switch(self, which):
        if which == "Installed":
            self.browse.pack_forget()
            self.installed.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        else:
            self.installed.pack_forget()
            self.browse.pack(fill="both", expand=True)

    def on_show(self):
        p = self.profile()
        self.info.configure(text=f"{p['name']}  -  {p['loader']} {p['version']}")
        for w in self.installed.winfo_children():
            w.destroy()
        if p["loader"] == "Vanilla":
            self.empty(self.installed, "This is a Vanilla profile. Set its loader to Fabric, Quilt or Forge "
                                       "in Profiles to use mods.")
            return
        d = self.mods_dir()
        files = sorted([f for f in d.glob("*.jar*") if f.suffix in (".jar", ".disabled")]) if d.exists() else []
        if not files:
            self.empty(self.installed, "No mods yet. Open the Browse Modrinth tab to add some.")
        for f in files:
            self.mod_row(f)

    def empty(self, parent, text):
        label(parent, text, 14, muted=True, wraplength=560, justify="left").pack(anchor="w", padx=14, pady=20)

    def mod_row(self, f: Path):
        on = f.suffix == ".jar"
        c = card(self.installed)
        c.pack(fill="x", padx=12, pady=4)
        sw = ctk.CTkSwitch(c, text="", width=40, progress_color=AMBER,
                           command=lambda f=f: self.toggle(f))
        sw.pack(side="left", padx=(14, 6), pady=12)
        if on:
            sw.select()
        name = f.name[:-9] if f.name.endswith(".disabled") else f.name
        lbl = label(c, name, 13)
        lbl.pack(side="left", padx=6)
        if not on:
            lbl.configure(text_color=MUTED)
        button(c, "Delete", lambda f=f: self.remove(f), "danger", width=70).pack(side="right", padx=12)
        label(c, human_size(f.stat().st_size), 12, muted=True).pack(side="right", padx=8)

    def toggle(self, f: Path):
        new = f.with_suffix("") if f.suffix == ".disabled" else f.with_name(f.name + ".disabled")
        try:
            f.rename(new)
        except OSError as e:
            messagebox.showerror("Mods", str(e))
        self.on_show()

    def remove(self, f: Path):
        if messagebox.askyesno("Delete mod", f"Delete {f.name}?"):
            f.unlink(missing_ok=True)
            self.on_show()

    # -- Modrinth ----------------------------------------------------------------------
    def search(self):
        p = self.profile()
        if p["loader"] == "Vanilla":
            self.msg.configure(text="Switch this profile to Fabric, Quilt or Forge first.")
            return
        self.msg.configure(text="Searching...")
        q = self.query.get().strip()

        def work():
            try:
                hits = modrinth_search(q, p["version"], p["loader"])
                self.app.post(self.show_results, hits)
            except Exception as e:
                self.app.post(self.msg.configure, text=f"Search failed: {e}")
        threading.Thread(target=work, daemon=True).start()

    def show_results(self, hits):
        for w in self.results.winfo_children():
            w.destroy()
        p = self.profile()
        self.msg.configure(text=f"{len(hits)} results for {p['loader']} {p['version']}" if hits
                           else "Nothing matched. Try another search.")
        for h in hits:
            c = card(self.results)
            c.pack(fill="x", padx=12, pady=4)
            left = ctk.CTkFrame(c, fg_color="transparent")
            left.pack(side="left", fill="x", expand=True, padx=16, pady=12)
            label(left, h["title"], 15, "bold").pack(anchor="w")
            label(left, f"by {h['author']}   -   {h['downloads']:,} downloads", 11, muted=True).pack(anchor="w")
            label(left, h["description"], 12, wraplength=470, justify="left").pack(anchor="w", pady=(4, 0))
            b = button(c, "Install", None, "primary", width=90)
            b.configure(command=lambda h=h, b=b: self.install(h, b))
            b.pack(side="right", padx=14)

    def install(self, hit, btn):
        p = self.profile()
        btn.configure(state="disabled", text="Installing...")

        def work():
            try:
                done = install_mod(hit["project_id"], p["version"], p["loader"], self.mods_dir())
                self.app.post(btn.configure, text="Installed", state="disabled")
                self.app.post(self.msg.configure, text=f"Installed {', '.join(done)}")
            except Exception as e:
                self.app.post(btn.configure, text="Install", state="normal")
                self.app.post(self.msg.configure, text=f"Install failed: {e}")
        threading.Thread(target=work, daemon=True).start()


# ======================================================================================
# Worlds page
# ======================================================================================
class WorldsPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.header("Worlds", "Back up, open or remove saves for the selected profile.")
        folders = ctk.CTkFrame(self, fg_color="transparent")
        folders.pack(fill="x", padx=28, pady=(0, 10))
        for text, sub in (("Game folder", ""), ("Screenshots", "screenshots"), ("Resource packs", "resourcepacks"),
                          ("Shader packs", "shaderpacks"), ("Logs", "logs"), ("Backups", None)):
            button(folders, text, lambda s=sub: self.open_sub(s), width=100).pack(side="left", padx=(0, 6))
        self.list = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list.pack(fill="both", expand=True, padx=16, pady=(0, 16))

    def open_sub(self, sub):
        base = BACKUPS_DIR if sub is None else game_dir_for(self.app.store.profile()) / sub
        open_path(base)

    def saves_dir(self) -> Path:
        return game_dir_for(self.app.store.profile()) / "saves"

    def on_show(self):
        for w in self.list.winfo_children():
            w.destroy()
        d = self.saves_dir()
        worlds = sorted([w for w in d.iterdir() if (w / "level.dat").exists()],
                        key=lambda w: w.stat().st_mtime, reverse=True) if d.exists() else []
        if not worlds:
            label(self.list, "No worlds in this profile yet. Create one in-game and it will appear here.",
                  14, muted=True).pack(anchor="w", padx=14, pady=20)
        for w in worlds:
            self.world_row(w)

    def world_row(self, w: Path):
        c = card(self.list)
        c.pack(fill="x", padx=12, pady=4)
        left = ctk.CTkFrame(c, fg_color="transparent")
        left.pack(side="left", padx=18, pady=12)
        label(left, w.name, 15, "bold").pack(anchor="w")
        info = label(left, f"Played {fmt_date(w.stat().st_mtime)}   -   measuring size...", 12, muted=True)
        info.pack(anchor="w")
        threading.Thread(target=lambda: self.app.post(
            info.configure, text=f"Played {fmt_date(w.stat().st_mtime)}   -   {human_size(dir_size(w))}"),
            daemon=True).start()
        right = ctk.CTkFrame(c, fg_color="transparent")
        right.pack(side="right", padx=14)
        button(right, "Back up", lambda w=w: self.backup(w), width=80).pack(side="left", padx=3)
        button(right, "Open", lambda w=w: open_path(w), width=60).pack(side="left", padx=3)
        button(right, "Delete", lambda w=w: self.delete(w), "danger", width=70).pack(side="left", padx=3)

    def backup(self, w: Path):
        self.app.set_status(f"Backing up {w.name}...")

        def work():
            try:
                BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
                dest = BACKUPS_DIR / f"{w.name}-{time.strftime('%Y%m%d-%H%M%S')}"
                out = shutil.make_archive(str(dest), "zip", root_dir=w.parent, base_dir=w.name)
                self.app.post(self.app.set_status, f"Backup saved: {out}")
            except Exception as e:
                self.app.post(self.app.set_status, f"Backup failed: {e}")
        threading.Thread(target=work, daemon=True).start()

    def delete(self, w: Path):
        if messagebox.askyesno("Delete world", f"Permanently delete '{w.name}'?\n\nThis cannot be undone. "
                                               "Consider backing it up first.", icon="warning"):
            shutil.rmtree(w, ignore_errors=True)
            self.on_show()


# ======================================================================================
# Console page
# ======================================================================================
class ConsolePage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        h = self.header("Console", "Live output from the game process.")
        tools = ctk.CTkFrame(h, fg_color="transparent")
        tools.place(relx=1.0, rely=0.5, anchor="e")
        self.kill_btn = button(tools, "Kill game", app.kill_game, "danger", width=90)
        self.kill_btn.pack(side="left", padx=4)
        button(tools, "Copy", self.copy, width=70).pack(side="left", padx=4)
        button(tools, "Save", self.save, width=70).pack(side="left", padx=4)
        button(tools, "Clear", self.clear, width=70).pack(side="left", padx=4)
        self.box = ctk.CTkTextbox(self, font=ctk.CTkFont(family="DejaVu Sans Mono", size=12),
                                  fg_color=("#f0f3f7", "#0d1014"), text_color=INK, corner_radius=10,
                                  wrap="none", state="disabled")
        self.box.pack(fill="both", expand=True, padx=28, pady=(0, 24))
        t = self.box._textbox
        t.tag_config("err", foreground="#ff7b6b")
        t.tag_config("warn", foreground="#f0b44a")
        t.tag_config("info", foreground="#8f98a6")

    def append(self, text):
        t = self.box._textbox
        up = text.upper()
        tag = "err" if ("ERROR" in up or "EXCEPTION" in up or "FATAL" in up) else \
              "warn" if "WARN" in up else "info" if text.startswith("[launcher]") else ""
        self.box.configure(state="normal")
        t.insert("end", text, tag)
        if int(t.index("end-1c").split(".")[0]) > 6000:
            t.delete("1.0", "1000.0")
        self.box.configure(state="disabled")
        t.see("end")

    def clear(self):
        self.box.configure(state="normal")
        self.box.delete("1.0", "end")
        self.box.configure(state="disabled")
        self.app.logbuf.clear()

    def copy(self):
        self.clipboard_clear()
        self.clipboard_append(self.box.get("1.0", "end"))

    def save(self):
        f = filedialog.asksaveasfilename(defaultextension=".log", initialfile="cubelight.log")
        if f:
            Path(f).write_text(self.box.get("1.0", "end"))


# ======================================================================================
# Settings page
# ======================================================================================
class SettingsPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.header("Settings")
        body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        s = app.store.settings

        def section(title):
            c = card(body)
            c.pack(fill="x", padx=12, pady=6)
            label(c, title, 15, "bold").pack(anchor="w", padx=18, pady=(14, 6))
            return c

        def line(c, text, widget_factory):
            r = ctk.CTkFrame(c, fg_color="transparent")
            r.pack(fill="x", padx=18, pady=5)
            label(r, text, 13).pack(side="left")
            w = widget_factory(r)
            w.pack(side="right")
            return w

        c = section("Personalize")
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=5)
        label(r, "Launcher name", 13).pack(side="left")
        self.name_e = entry(r, width=260)
        self.name_e.insert(0, s["app_name"])
        self.name_e.pack(side="right")
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=5)
        label(r, "Tagline", 13).pack(side="left")
        self.tag_e = entry(r, width=260)
        self.tag_e.insert(0, s["tagline"])
        self.tag_e.pack(side="right")
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=5)
        label(r, "Banner image", 13).pack(side="left")
        button(r, "Reset", self.reset_banner, width=60).pack(side="right")
        button(r, "Choose image", self.choose_banner, width=110).pack(side="right", padx=6)
        self.banner_lbl = label(c, s["banner"] or "Using the built-in block art", 12, muted=True)
        self.banner_lbl.pack(anchor="w", padx=18)
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=(8, 14))
        button(r, "Apply", self.apply_branding, "primary", width=80).pack(side="right")
        label(r, "PNG, GIF" + (", JPG, WebP" if Image else " (install Pillow for JPG/WebP)") + ". Wide images work best.", 12, muted=True).pack(side="left")

        c = section("Launcher")
        line(c, "Appearance", lambda r: option_menu(r, ["Dark", "Light", "System"], self.set_appearance,
                                                    width=150)).set(s["appearance"])
        line(c, "After the game starts", lambda r: option_menu(r, AFTER_LAUNCH, self.set_after,
                                                               width=190)).set(s["after_launch"])
        self.snap = line(c, "Show snapshots in version lists", lambda r: ctk.CTkSwitch(
            r, text="", progress_color=AMBER, command=self.set_snap))
        if s["show_snapshots"]:
            self.snap.select()
        ctk.CTkFrame(c, fg_color="transparent", height=8).pack()

        c = section("Game defaults")
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=5)
        label(r, f"Default memory  (this PC has {system_ram_mb() / 1024:.1f} GB)", 13).pack(side="left")
        self.ram_lbl = label(r, "", 13, width=80)
        self.ram_lbl.pack(side="right")
        hi = max_ram_mb()
        sl = ctk.CTkSlider(r, from_=1024, to=hi, number_of_steps=max(1, (hi - 1024) // 256), width=220,
                           progress_color=AMBER, button_color=AMBER, button_hover_color=AMBER_HOVER,
                           command=self.set_ram)
        sl.set(min(max(s["default_ram"], 1024), hi))
        sl.pack(side="right", padx=10)
        self.set_ram(sl.get(), save=False)

        javas = find_javas()
        self.java_map = {"Automatic (Mojang runtime)": ""}
        for lbl, path in javas:
            self.java_map[f"{lbl}  -  {path}"] = path
        j = line(c, "Java", lambda r: option_menu(r, list(self.java_map), self.set_java, width=340))
        j.set(next((k for k, v in self.java_map.items() if v == s["java_path"]), "Automatic (Mojang runtime)"))
        ctk.CTkFrame(c, fg_color="transparent", height=8).pack()

        c = section("Storage")
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=5)
        label(r, "Shared game files", 13).pack(side="left")
        button(r, "Open", lambda: open_path(app.mc_dir), width=60).pack(side="right")
        button(r, "Change", self.change_dir, width=70).pack(side="right", padx=6)
        self.dir_lbl = label(c, s["mc_dir"], 12, muted=True)
        self.dir_lbl.pack(anchor="w", padx=18, pady=(0, 6))
        label(c, "Versions, libraries and assets are shared by every profile to save disk space.",
              12, muted=True).pack(anchor="w", padx=18, pady=(0, 6))
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=(2, 14))
        label(r, "Re-download missing files for the selected profile", 13).pack(side="left")
        button(r, "Verify and repair", app.repair, width=130).pack(side="right")

        c = section("About")
        label(c, f"{APP} {APP_VERSION}  -  offline launcher built on minecraft-launcher-lib "
                 f"{mll.utils.get_library_version()}", 12, muted=True).pack(anchor="w", padx=18)
        label(c, "Offline mode does not verify purchases. Please buy the game to support Mojang.",
              12, muted=True).pack(anchor="w", padx=18, pady=(2, 6))
        r = ctk.CTkFrame(c, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=(0, 14))
        button(r, "Config folder", lambda: open_path(CONFIG_DIR), width=110).pack(side="left", padx=(0, 6))
        button(r, "Data folder", lambda: open_path(DATA_DIR), width=100).pack(side="left")

    def apply_branding(self):
        st = self.app.store.settings
        st["app_name"] = self.name_e.get().strip() or APP
        st["tagline"] = self.tag_e.get().strip()
        self.app.store.save()
        self.app.apply_branding()

    def choose_banner(self):
        f = filedialog.askopenfilename(
            title="Choose a banner image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.gif *.bmp"), ("All files", "*.*")])
        if f:
            self.app.store.settings["banner"] = f
            self.app.store.save()
            self.app.apply_branding()
            play = self.app.pages["play"]
            play.banner_image(max(play.hero.winfo_width(), 840), 280)  # test-load now
            if play.banner_error:
                messagebox.showerror("Banner image", f"Could not use this image.\n\n{play.banner_error}")
                self.banner_lbl.configure(text=f"Failed: {play.banner_error}", text_color=DANGER)
            else:
                self.banner_lbl.configure(text=f, text_color=MUTED)

    def reset_banner(self):
        self.app.store.settings["banner"] = ""
        self.app.store.save()
        self.banner_lbl.configure(text="Using the built-in block art")
        self.app.apply_branding()

    def set_appearance(self, v):
        self.app.store.settings["appearance"] = v
        self.app.store.save()
        ctk.set_appearance_mode(v)
        self.app.after(50, self.app.pages["play"].draw_hero)

    def set_after(self, v):
        self.app.store.settings["after_launch"] = v
        self.app.store.save()

    def set_snap(self):
        self.app.store.settings["show_snapshots"] = bool(self.snap.get())
        self.app.store.save()

    def set_ram(self, v, save=True):
        self.ram_lbl.configure(text=f"{int(v)} MB")
        if save:
            self.app.store.settings["default_ram"] = int(v)
            self.app.store.save()

    def set_java(self, v):
        self.app.store.settings["java_path"] = self.java_map.get(v, "")
        self.app.store.save()

    def change_dir(self):
        d = filedialog.askdirectory(initialdir=self.app.mc_dir)
        if d:
            self.app.store.settings["mc_dir"] = d
            self.app.store.save()
            self.dir_lbl.configure(text=d)


# ======================================================================================
# Application
# ======================================================================================
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        global FAMILY
        import tkinter.font as tkfont
        avail = set(tkfont.families())
        FAMILY = next((f for f in ("Inter", "Noto Sans", "Cantarell", "Ubuntu", "DejaVu Sans") if f in avail),
                      "TkDefaultFont")
        self.store = Store()
        ctk.set_appearance_mode(self.store.settings["appearance"])
        self.title(self.store.settings['app_name'] or APP)
        self.geometry("1040x680")
        self.minsize(940, 620)
        self.configure(fg_color=BG)

        self.q: queue.Queue = queue.Queue()
        self.proc: subprocess.Popen | None = None
        self.busy = False
        self.force_repair = False
        self.logbuf: list[str] = []
        self.version_cache: list[dict] | None = None

        side = ctk.CTkFrame(self, width=200, corner_radius=0, fg_color=SIDE)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        self.brand_lbl = label(side, "", 22, "bold")
        self.brand_lbl.pack(anchor="w", padx=22, pady=(26, 2))
        self.tag_lbl = label(side, "", 12, muted=True, wraplength=160, justify="left")
        self.tag_lbl.pack(anchor="w", padx=22, pady=(0, 22))

        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.pack(side="left", fill="both", expand=True)
        self.statusbar = label(self.content, "", 12, muted=True)
        self.statusbar.pack(side="bottom", anchor="w", padx=28, pady=(0, 8))

        self.pages: dict[str, Page] = {}
        self.nav: dict[str, ctk.CTkButton] = {}
        specs = [("play", "Play", PlayPage), ("profiles", "Profiles", ProfilesPage),
                 ("mods", "Mods", ModsPage), ("worlds", "Worlds", WorldsPage),
                 ("console", "Console", ConsolePage), ("settings", "Settings", SettingsPage)]
        for key, text, cls in specs:
            self.pages[key] = cls(self.content, self)
            b = ctk.CTkButton(side, text=text, anchor="w", height=40, corner_radius=8, font=font(14),
                              fg_color="transparent", text_color=INK, hover_color=CARD_HI,
                              command=lambda k=key: self.show(k))
            b.pack(fill="x", padx=12, pady=2)
            self.nav[key] = b
        label(side, f"{APP_VERSION}", 11, muted=True).pack(side="bottom", anchor="w", padx=22, pady=16)

        self.current = None
        self.apply_branding()
        self.show("play")
        self.after(40, self._pump)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.fetch_versions()

    # -- plumbing ----------------------------------------------------------------------
    @property
    def mc_dir(self) -> str:
        return self.store.settings["mc_dir"]

    def post(self, fn, *a, **k):
        """Run fn(*a, **k) on the UI thread. Safe to call from any thread."""
        self.q.put((fn, a, k))

    def _pump(self):
        try:
            while True:
                fn, a, k = self.q.get_nowait()
                try:
                    fn(*a, **k)
                except tk.TclError:
                    pass
        except queue.Empty:
            pass
        self.after(40, self._pump)

    def show(self, key):
        if self.current:
            self.pages[self.current].pack_forget()
        self.current = key
        self.pages[key].pack(fill="both", expand=True)
        self.pages[key].on_show()
        for k, b in self.nav.items():
            b.configure(fg_color=CARD_HI if k == key else "transparent")

    def apply_branding(self):
        st = self.store.settings
        name = st["app_name"] or APP
        self.title(name)
        self.brand_lbl.configure(text=name if len(name) <= 14 else name[:13] + "...")
        self.tag_lbl.configure(text=st["tagline"][:60])
        self.pages["play"].draw_hero()

    def set_status(self, text):
        self.statusbar.configure(text=text)
        self.pages["play"].set_status(text)

    def log(self, text):
        if not text.endswith("\n"):
            text += "\n"
        self.logbuf.append(text)
        self.pages["console"].append(text)

    # -- versions ----------------------------------------------------------------------
    def fetch_versions(self, done=None):
        def work():
            try:
                self.version_cache = mll.utils.get_version_list()
            except Exception:
                pass
            if done:
                self.post(done)
        threading.Thread(target=work, daemon=True).start()

    def version_choices(self, snapshots=False) -> list[str]:
        if self.version_cache:
            kinds = {"release", "snapshot"} if snapshots else {"release"}
            return [v["id"] for v in self.version_cache if v["type"] in kinds]
        return [i for i in installed_ids(self.mc_dir) if i[0].isdigit()] or ["1.20.4"]

    def default_version(self) -> str:
        return (self.version_choices() or ["1.20.4"])[0]

    # -- launching ---------------------------------------------------------------------
    def on_play_button(self):
        if self.proc and self.proc.poll() is None:
            self.kill_game()
        elif not self.busy:
            self.launch()

    def kill_game(self):
        if self.proc and self.proc.poll() is None:
            self.log("[launcher] Stopping the game...")
            self.proc.terminate()
            threading.Timer(6, lambda: self.proc and self.proc.poll() is None and self.proc.kill()).start()

    def repair(self):
        self.force_repair = True
        self.show("play")
        self.launch(install_only=True)

    def make_callback(self):
        state = {"max": 1, "last": -1.0}

        def set_max(m):
            state["max"] = max(int(m), 1)

        def set_progress(v):
            frac = v / state["max"]
            if frac - state["last"] >= 0.005 or frac >= 1:
                state["last"] = frac
                self.post(self.pages["play"].set_progress, frac)

        def set_status(s):
            self.post(self.set_status, s)
            self.post(self.log, f"[launcher] {s}")
        return {"setStatus": set_status, "setProgress": set_progress, "setMax": set_max}

    def launch(self, install_only=False):
        play = self.pages["play"]
        user = play.account.get().strip()
        if not install_only and not valid_username(user):
            messagebox.showerror("Username", "Pick a name with 3-16 letters, numbers or underscores.")
            return
        s = self.store
        if not install_only:
            if user not in s.data["accounts"]:
                s.data["accounts"].append(user)
            s.data["active_account"] = user
            s.save()
            play.account.configure(values=s.data["accounts"])
        self.busy = True
        play.set_state("busy")
        play.set_progress(0)
        threading.Thread(target=self._worker, args=(dict(s.profile()), user, install_only), daemon=True).start()

    def _worker(self, p, user, install_only):
        try:
            vid = resolve_version(self.mc_dir, p)
            if vid is None or self.force_repair:
                self.post(self.set_status, f"Downloading Minecraft {p['version']}"
                                           f"{'' if p['loader'] == 'Vanilla' else ' + ' + p['loader']}...")
                install_profile(self.mc_dir, p, self.make_callback())
                vid = resolve_version(self.mc_dir, p)
                if not vid:
                    raise RuntimeError("Install finished but the version was not found.")
            self.force_repair = False
            if install_only:
                self.post(self.set_status, "All files verified.")
                self.post(self.pages["play"].set_progress, 1)
                self.post(self.pages["play"].set_state, "idle")
                self.busy = False
                return

            game_dir = game_dir_for(p)
            game_dir.mkdir(parents=True, exist_ok=True)
            cmd = build_command(self.mc_dir, p, self.store.settings, user, vid)
            mode = self.store.settings["after_launch"]
            detach = mode == "Close launcher"
            self.post(self.log, "[launcher] " + " ".join(shlex.quote(c) for c in cmd))
            self.post(self.set_status, f"Playing as {user}")
            self.post(self.pages["play"].set_progress, 1)
            proc = subprocess.Popen(
                cmd, cwd=str(game_dir), text=True, errors="replace", bufsize=1,
                stdout=subprocess.DEVNULL if detach else subprocess.PIPE,
                stderr=subprocess.DEVNULL if detach else subprocess.STDOUT,
                start_new_session=detach)
            self.proc = proc
            for pr in self.store.profiles:
                if pr["id"] == p["id"]:
                    pr["last_played"] = time.time()
            self.store.save()
            if detach:
                self.post(self.destroy)
                return
            self.post(self.pages["play"].set_state, "running")
            if mode == "Hide while playing":
                self.post(self.withdraw)
            started = time.time()
            for line in proc.stdout:
                self.post(self.log, line.rstrip("\n"))
            code = proc.wait()
            elapsed = int(time.time() - started)
            for pr in self.store.profiles:
                if pr["id"] == p["id"]:
                    pr["playtime"] += elapsed
            self.store.save()
            self.post(self.on_game_exit, code)
        except Exception as e:
            self.force_repair = False
            self.post(self.on_error, e)

    def on_error(self, e):
        self.busy = False
        self.pages["play"].set_state("idle")
        self.set_status("Something went wrong.")
        self.log(f"[launcher] ERROR: {e}")
        messagebox.showerror("Could not start", f"{e}\n\nSee the Console tab for details.")

    def on_game_exit(self, code):
        self.deiconify()
        self.busy = False
        self.proc = None
        play = self.pages["play"]
        play.set_state("idle")
        play.set_progress(0)
        play.update_stats()
        ok = code in (0, None, -15, 143)
        self.set_status("Game closed." if ok else f"Game exited with code {code}. Open Console for the log.")
        self.log(f"[launcher] Game exited with code {code}")
        if not ok:
            self.show("console")

    def on_close(self):
        if self.proc and self.proc.poll() is None:
            if not messagebox.askyesno(APP, "Minecraft is still running. Quit the launcher and stop the game?"):
                return
            self.proc.terminate()
        self.destroy()


def main():
    ctk.set_default_color_theme("blue")
    App().mainloop()


if __name__ == "__main__":
    main()
#!/usr/bin/env bash
# Sets up a virtualenv and adds Cubelight to your application menu.
set -e
cd "$(dirname "$(readlink -f "$0")")"
HERE="$PWD"

python3 -c "import tkinter" 2>/dev/null || {
  echo "Tkinter is missing. Install it first:"
  echo "  Debian/Ubuntu: sudo apt install python3-tk"
  echo "  Fedora:        sudo dnf install python3-tkinter"
  echo "  Arch:          sudo pacman -S tk"
  exit 1
}

python3 -m venv --system-site-packages .venv
.venv/bin/pip install -q -r requirements.txt

cat > run.sh <<RUN
#!/usr/bin/env bash
exec "$HERE/.venv/bin/python" "$HERE/cubelight.py" "\$@"
RUN
chmod +x run.sh

mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/cubelight.desktop <<DESK
[Desktop Entry]
Type=Application
Name=Cubelight
Comment=Offline Minecraft launcher
Exec=$HERE/run.sh
Terminal=false
Categories=Game;
DESK

echo "Done. Start it from your app menu, or run: $HERE/run.sh"
